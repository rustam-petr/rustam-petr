<?php

namespace App;

class Square extends Figure implements IFigure
{
    use SquareTrait;
}