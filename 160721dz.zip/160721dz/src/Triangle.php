<?php


namespace App;


class Triangle extends Figure implements IFigure
{
     use TriangleTrait;
}