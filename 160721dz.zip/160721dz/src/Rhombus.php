<?php


namespace App;


class Rhombus extends Figure implements IFigure
{
use RhombusTrait;
}