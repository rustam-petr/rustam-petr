<?php  // создаем массив, содержащий переменные настройки работы с базой данных

$config["mysql"]["host"] = "localhost";
$config["mysql"]["user"] = "root";
$config["mysql"]["password"] = "root";
$config["mysql"]["bd"] = "crud";
$config["mysql"]["table"] = "vedomost";


